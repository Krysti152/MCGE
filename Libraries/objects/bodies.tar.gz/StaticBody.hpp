#pragma once

#ifndef STATIC_BODY_HPP
#define STATIC_BODY_HPP

#include <SFML/Graphics.hpp>
#include <MCGE/engine.hpp>

namespace gm {

class StaticBody : public gm::GameObject
{
private:
public:

    gm::CollisionShape shape;

    StaticBody() {
        
    }
    StaticBody(int _x, int _y) {
        shape = gm::CollisionShape(false);
        shape.transform.setPosition(_x,_y);
        shape.circle.setPosition(_x,_y);
        shape.rect.setPosition(_x,_y);
    }

    ~StaticBody() {
    }

    void start() {

    }

    void update() {
        
    }

};

}

#endif