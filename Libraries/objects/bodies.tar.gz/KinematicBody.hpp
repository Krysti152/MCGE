#pragma once

#ifndef KINEMATIC_BODY_HPP
#define KINEMATIC_BODY_HPP

#include <SFML/Graphics.hpp>
#include <MCGE/engine.hpp>

namespace gm {

class KinematicBody : public gm::GameObject
{
private:
public:

    gm::CollisionShape shape;

    KinematicBody() {
        
    }

    ~KinematicBody() {
    }

    void start() {

    }

    void update() {
        shape.circle.setPosition(shape.transform.position.x, shape.transform.position.y);
        shape.rect.setPosition(shape.transform.position.x, shape.transform.position.y);
    }
};

}

#endif